package main

import (
	"net"
	"os"
	"os/signal"
	"syscall"

	"github.com/cloudwebrtc/go-sip-ua/examples/mock"
	"github.com/cloudwebrtc/go-sip-ua/pkg/account"
	"github.com/cloudwebrtc/go-sip-ua/pkg/media/rtp"
	"github.com/cloudwebrtc/go-sip-ua/pkg/session"
	"github.com/cloudwebrtc/go-sip-ua/pkg/stack"
	"github.com/cloudwebrtc/go-sip-ua/pkg/ua"
	"github.com/cloudwebrtc/go-sip-ua/pkg/utils"
	"github.com/ghettovoice/gosip/log"
	"github.com/ghettovoice/gosip/sip"
)

var (
	logger = utils.NewLogrusLogger(log.InfoLevel, "Server", nil)
	udp    *rtp.RtpUDPStream
)

func createRtp() *rtp.RtpUDPStream {
	udp := rtp.NewRtpUDPStream("127.0.0.1", rtp.DefaultPortMin, rtp.DefaultPortMax, func(data []byte, raddr net.Addr) {
		logger.Infof("RTP received from %s, echoing %d bytes", raddr.String(), len(data))
		dest, _ := net.ResolveUDPAddr("udp", raddr.String())
		udp.Send(data, dest)
	})
	go udp.Read()
	return udp
}

func main() {
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)

	// Initialize SIP stack
	sipStack := stack.NewSipStack(&stack.SipStackConfig{
		UserAgent:  "Go SIP Server",
		Extensions: []string{"replaces", "outbound"},
		Dns:        "8.8.8.8",
	})

	listenAddr := "127.0.0.1:5081"
	logger.Infof("SIP Server listening on %s (UDP/TCP/WSS)", listenAddr)

	if err := sipStack.Listen("udp", listenAddr); err != nil {
		logger.Panicf("UDP listen error: %v", err)
	}
	if err := sipStack.Listen("tcp", listenAddr); err != nil {
		logger.Panicf("TCP listen error: %v", err)
	}
	if err := sipStack.ListenTLS("wss", "127.0.0.1:5091", nil); err != nil {
		logger.Panicf("WSS listen error: %v", err)
	}

	// Create UA (User Agent)
	userAgent := ua.NewUserAgent(&ua.UserAgentConfig{
		SipStack: sipStack,
	})

	// Handle INVITE requests (incoming calls)
	userAgent.InviteStateHandler = func(sess *session.Session, req *sip.Request, resp *sip.Response, state session.Status) {
		logger.Infof("Call state changed: %v (%s)", state, sess.Direction())

		switch state {
		case session.InviteReceived:
			logger.Infof("Incoming call from: %s", sess.RemoteURI())
			udp = createRtp()
			udpLaddr := udp.LocalAddr()
			sdp := mock.BuildLocalSdp(udpLaddr.IP.String(), udpLaddr.Port)
			sess.ProvideAnswer(sdp)
			sess.Accept(200)

		case session.Confirmed:
			logger.Infof("Call confirmed with %s", sess.RemoteURI())

		case session.Canceled, session.Failure, session.Terminated:
			logger.Infof("Call ended or failed")
			if udp != nil {
				udp.Close()
			}
		}
	}

	userAgent.RegisterStateHandler = func(state account.RegisterState) {
		logger.Infof("Registration state: %v, user: %s", state.StatusCode, state.Account.AuthInfo.AuthUser)
	}

	logger.Infof("SIP Server is ready.")

	<-stop
	logger.Infof("Shutting down SIP server...")
	userAgent.Shutdown()
}
