package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cloudwebrtc/go-sip-ua/pkg/account"
	"github.com/cloudwebrtc/go-sip-ua/pkg/stack"
	"github.com/cloudwebrtc/go-sip-ua/pkg/ua"
	"github.com/ghettovoice/gosip/sip"
	"github.com/ghettovoice/gosip/sip/parser"
)

func main() {
	// Create SIP Stack
	sipStack := stack.NewSipStack(&stack.SipStackConfig{
		UserAgent: "Go-SIP-Client",
	})

	// Start SIP stack listener
	err := sipStack.Listen("udp", "127.0.0.1:5060")
	if err != nil {
		fmt.Println("Error starting SIP stack:", err)
		return
	}

	// Create UserAgent
	userAgent := ua.NewUserAgent(&ua.UserAgentConfig{
		SipStack: sipStack,
	})

	// Parse local URI
	localURI, err := parser.ParseUri("sip:1001@127.0.0.1")
	if err != nil {
		fmt.Println("Parse local URI failed:", err)
		return
	}

	// Define profile
	profile := &account.Profile{
		URI:         localURI.(sip.Uri),
		DisplayName: "1001",
	}

	// Registration and call flow
	go func() {
		time.Sleep(1 * time.Second)

		// Registrar URI
		parsedRegistrar, err := parser.ParseUri("sip:127.0.0.1")
		if err != nil {
			fmt.Println("Parse registrar URI failed:", err)
			return
		}
		registrarURI := parsedRegistrar.(*sip.SipUri)

		// REGISTER
		_, err = userAgent.SendRegister(profile, *registrarURI, 3600, nil)
		if err != nil {
			fmt.Println("REGISTER failed:", err)
			return
		}
		fmt.Println("REGISTER sent")

		time.Sleep(2 * time.Second)

		// Target URI
		parsedTarget, err := parser.ParseUri("sip:1002@127.0.0.1")
		if err != nil {
			fmt.Println("Parse INVITE URI failed:", err)
			return
		}
		targetURI := parsedTarget.(*sip.SipUri)

		// INVITE
		session, err := userAgent.Invite(profile, localURI.(*sip.SipUri), *targetURI, nil)
		if err != nil {
			fmt.Println("INVITE failed:", err)
			return
		}
		fmt.Println("Call started.")

		time.Sleep(10 * time.Second)

		// End the session
		if session != nil {
			fmt.Println("Ending call...")
			session.Bye() //  changed from Terminate()
		}
	}()

	// Wait for SIGINT/SIGTERM
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	<-sigs

	fmt.Println("Shutting down...")
	userAgent.Shutdown()
}
